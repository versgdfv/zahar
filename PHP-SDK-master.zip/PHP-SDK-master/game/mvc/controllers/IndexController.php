<?php
/**
 * @Controller
 */
class IndexController extends XAbstractController{
	public function doIndex(){
	}
}
?>