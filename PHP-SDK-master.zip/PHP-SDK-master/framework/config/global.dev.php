<?php
//全局信息配置文件
return array(
	//设置默认语言种类
	'language'=>'cn',
	//设置默认时区
	'timezone'=>'Asia/Shanghai',
	//设置默认字符编码
	'encode'=>'utf-8',
)
?>