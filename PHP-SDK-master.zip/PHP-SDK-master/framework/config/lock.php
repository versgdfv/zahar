<?php
//锁信息配置文件
//return array(
//	'memcache' => array(
//		'type' => 'cache',
//		'instance' => 'memcache',
//	),
//);
?>