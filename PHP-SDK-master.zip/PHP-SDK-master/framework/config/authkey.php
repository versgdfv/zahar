<?php
return array(
	'oauth' => array(
		'consumer_key' => '#consumer_key#',
		'secret_key' => '#secret_key#',
	),
	'admin' => array(
		'consumer_key' => '#consumer_key#',
		'secret_key' => '#secret_key#',
	),
);
?>