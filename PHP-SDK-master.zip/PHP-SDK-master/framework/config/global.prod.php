<?php
return array(
	'language'=>'cn',
	'timezone'=>'Asia/Shanghai',
	'encode'=>'utf-8',
)
?>