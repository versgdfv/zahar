<?php
import('module.event.XApplicationEvent');
/**
 * ActionErrorEvent
 * 
 * action error event
 * 
 * action错误事件，Action调用出现错误后会发布该事件。
 * 
 * @author Wangqi
 * @package action
 */
class ActionErrorEvent extends XApplicationEvent{
}
?>