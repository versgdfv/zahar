<?php
/**
 * UserAccount
 * 
 * user account
 * 
 * 用户账户
 * 
 * @Entity
 * @package user
 * @author WangQi
 */
import('service.user.AbstractAccount');
class UserAccount extends AbstractAccount{
}
?>