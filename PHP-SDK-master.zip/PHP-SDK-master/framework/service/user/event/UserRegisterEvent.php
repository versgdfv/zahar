<?php
import('module.event.XApplicationEvent');
/**
 * UserRegisterEvent
 * 
 * user register event
 * 
 * 用户注册事件
 * 用户注册时会发布该事件
 * 
 * @author Wangqi
 * @package user
 */
class UserRegisterEvent extends XApplicationEvent{	
}
?>