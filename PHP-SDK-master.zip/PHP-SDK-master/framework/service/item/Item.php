<?php
/**
 * Item
 * 
 * item interface
 * 
 * item接口
 * 
 * @author Tianwei
 * @interface
 * @package item
 */
interface Item{
	function getId();
	function getName();
}
?>