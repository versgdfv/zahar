<?php
import('module.event.XApplicationEvent');
/**
 * ServiceStartedEvent
 * 
 * service started event
 * 
 * service开始事件
 * 
 * @author Tianwei
 * @package service
 */
class ServiceStartedEvent extends XApplicationEvent{
}
?>