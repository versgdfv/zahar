<?php
/**
 * XService
 * 
 * service interface
 * 
 * service接口
 * 
 * @author Tianwei
 * @interface
 * @package service 
 */
interface XService{
}
?>