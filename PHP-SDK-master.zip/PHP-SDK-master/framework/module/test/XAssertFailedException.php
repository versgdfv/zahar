<?php
/**
 * XAssertFailedException
 * 
 * assert failed exception
 * 
 * 校验错误时抛出异常
 * 
 * @author Wangqi
 * @package test 
 */
class XAssertFailedException extends XException{

}
?>