<?php
/**
 * XTestCase
 * 
 * testcase inteface
 * 
 * testcase接口
 * 
 * @author Wangqi
 * @interface
 * @package test 
 */
interface XTestCase{
	/**
	 * run the testcases
	 * 
	 * 运行testcase
	 */
	public function run();
}
?>