<?php
/**
 * XContext
 * 
 * context interface
 * 
 * 实现程序上下文类的接口，用来提供上下文相关服务
 * 
 * @author Tianwei
 * @interface
 * @package context 
 */
interface XContext{
}
?>