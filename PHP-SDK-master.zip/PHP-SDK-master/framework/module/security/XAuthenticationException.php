<?php
import('module.context.XException');
/**
 * XAuthenticationException
 * 
 * authentication exeption
 * 
 * 验证异常类
 * 
 * @author Tianwei
 * @package security
 */
class XAuthenticationException extends XException{
}
?>