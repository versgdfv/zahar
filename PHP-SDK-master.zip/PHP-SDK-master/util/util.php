<?php
if(!isset($utilLoaded) || !$utilLoaded){
	require 'defines.php';
	require 'functions.php';
	static $utilLoaded = true;
}
?>