<?php
class UserProfileTestCase extends BaseServiceTestCase{
	public function testGetItems(){
		$user = new UserProfile();
	}
}
?>