<h3>Test Tools</h3>
<div><a href='/test/admin/index.php'>Admin (GM)</a></div>
<div><a href='/test/amf/index.html'>AMF</a></div>
<div><a href='/test/api/index.php'>API Discovery</a></div>
<div><a href='/test/gdp/index.html'>GDP</a></div>
<div><a href='/test/jsonrpc/index.php'>JSON RPC</a></div>
<div><a href='/test/rest/index.php'>REST</a></div>
<div><a href='/test/testcase/index.php'>Unit Test</a></div>