/*以下是需要配置的信息*/
var game_client = "client/TestApp.swf"; 	/*主flash的地址*/
var uid = "testuid1";						/*当前用户的uid*/

/*定义user信息*/
var userInfo = new Object();	
userInfo['id'] = uid;
userInfo['name'] = uid;
userInfo['sex'] = "1";
userInfo['birthDate'] = "";
userInfo['city'] = "";
userInfo['url'] = "";
userInfo['photoSmall'] = "";
userInfo['photoMedium'] = "";
userInfo['photoBig'] = "";
/*定义user信息结束*/

/*定义friend信息*/
var friendInfo = new Array();	/*定义friend信息*/

Info = new Object();
Info['id'] = "testuid1";
Info['name'] = "testuid1";
Info['sex'] = "1";
Info['birthDate'] = "";
Info['city'] = "";
Info['url'] = "";
Info['photoSmall'] = "";
Info['photoMedium'] = "";
Info['photoBig'] = "";
friendInfo.push(Info);

Info = new Object();
Info['id'] = "testuid2";
Info['name'] = "testuid2";
Info['sex'] = "1";
Info['birthDate'] = "";
Info['city'] = "";
Info['url'] = "";
Info['photoSmall'] = "";
Info['photoMedium'] = "";
Info['photoBig'] = "";
friendInfo.push(Info);

Info = new Object();
Info['id'] = "testuid3";
Info['name'] = "testuid3";
Info['sex'] = "1";
Info['birthDate'] = "";
Info['city'] = "";
Info['url'] = "";
Info['photoSmall'] = "";
Info['photoMedium'] = "";
Info['photoBig'] = "";
friendInfo.push(Info);

Info = new Object();
Info['id'] = "testuid4";
Info['name'] = "testuid4";
Info['sex'] = "1";
Info['birthDate'] = "";
Info['city'] = "";
Info['url'] = "";
Info['photoSmall'] = "";
Info['photoMedium'] = "";
Info['photoBig'] = "";
friendInfo.push(Info);
/*定义friend信息结束*/